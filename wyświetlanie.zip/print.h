#ifndef PRINT_H
#define PRINT_H

typedef struct 
 { 
   char name[50];
   char surname[50];
   int IndexNr;
   float avg;

 } Student;

void PrintAll(int a, Student students[a]);
void PrintByName(int a, Student students[a]);
void PrintBySurname(int a, Student students[a]);
void PrintByIndexNr(int a, Student students[a]);
void PrintByAvg(int a, Student students[a]);

#endif 