#include "load_and_save.h"
#include "search.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int SearchByIndex(struct Student* database, int databaseSize)
{
    int answer, end;
    do
    {
        printf("\nWpisz numer wyszukiwanego indeksu: ");
        scanf("%d", &answer);
        if (answer<10000 && answer>=0)
        {
            for (int i = 0; i < databaseSize; i++)
            {
                if (database[i].IndexNr == answer)
                    {
                        printf("%s %s, numer:%d, srednia:%f",database[i].name, database[i].surname, database[i].IndexNr, database[i].avg);
                        return i;
                    }
            }
        }
        printf("\nNie ma takiego indeksu.\nNapisz 1 jesli chcesz ponowic probe: ");
        scanf("%d", &end);
    } while (end == 1);
    return -1;
}

int SearchBySurname(struct Student* database, int databaseSize)
{
    char answer[50];
    int end, count = 0;
    int tab[10];
    do
    {
        printf("\nWpisz nazwisko studenta ktorego szukasz: ");
        scanf("%s", answer);

        for (int i = 0; i < databaseSize; i++)
        {
            if (CompareStrings(database[i].surname, answer))
            {
                tab[count] = i;
                count++;
            }
        }
        if (count == 1)
        {
            printf("\n%s %s, numer:%d, srednia:%f",database[tab[0]].name, database[tab[0]].surname, database[tab[0]].IndexNr, database[tab[0]].avg);
            return tab[0];
        }
        else if (count != 0)
        {
            int j = 1, c;
            for (j; j < count + 1; j++)
            {
                printf("\n%d) %s %s, numer:%d, srednia:%f", j, database[tab[j - 1]].name, database[tab[j - 1]].surname, database[tab[j - 1]].IndexNr, database[tab[j - 1]].avg);
            }
            printf("\nWybierz numer przy studencie o którego ci chodzi,a jesli go nie ma wpisz dowolna inna liczbe: ");
            scanf("%d", &c);
            if (c > 0 && c < j + 1)
            {
                return tab[c - 1];
            }
            else
            {
                printf("\nNie wybrales żadnego studenta. Jesli chcesz wyszukac ponownie, wpisz 1: ");
            }
        }
        else
        {
            printf("\nNie ma studenta o takim nazwisku.\nWpisz 1 jeśli chcesz ponowic próbę: ");
        }
        scanf("%d", &end);
    } while (end == 1);
    return -1;
}

int CompareStrings(char str1[], char str2[])
{
    if (strlen(str1) == strlen(str2))
    {
        for (int i = 0; i < strlen(str1); i++)
        {
            if (tolower(str1[i]) != tolower(str2[i]))
            {
                return 0;
            }
        }
        return 1;
    }
    else
    {
        return 0;
    }
}