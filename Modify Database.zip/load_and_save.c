#include "load_and_save.h"
#include <stdio.h>
void LoadDatabase(const char* file_name, struct Student** database, int* databaseSize)
{
    FILE* plik = fopen(file_name, "r");
    if (plik == NULL)
    {
        printf("Nie udalo sie otworzyc pliku.\n");
        return;
    }

    *databaseSize = 50;
    *database = malloc(*databaseSize * sizeof(struct Student));
    int studentNr = 0;


    // Pominięcie pierwszej linii pliku csv
    char buffer[100];
    if (fgets(buffer, sizeof(buffer), plik) == NULL)
    {
        printf("\nBlad podczas czytania pierwszej linii :(\n");
        fclose(plik);
        return;
    }

    do
    {
        if (studentNr == *databaseSize)
        {
            (*databaseSize)++;
            *database = realloc(*database, *databaseSize * sizeof(struct Student));
        }

        if (fscanf(plik, "%49[^,],%49[^,],%d,%f\n", (*database)[studentNr].name,
                   (*database)[studentNr].surname, &(*database)[studentNr].IndexNr, &(*database)[studentNr].avg) == 4)
        {
            studentNr++;
        }
        else
        {
            printf("Blad formatowania pliku :( \n");
            break;
        }
    } while (!feof(plik));

    fclose(plik);
}

void SaveToFile(const char* file_name, struct Student* database, int databaseSize)
{
    FILE *plik = fopen(file_name, "w");

    if (plik == NULL)
    {
        printf("\nBlad przy otwieraniu pliku :(\n");
        return;
    }

    fprintf(plik, "Imię,Nazwisko,Numer Indeksu,Średnia\n");

    for (int i = 0; i < databaseSize; i++)
    {
        fprintf(plik, "%s,%s,%d,%.2f\n", database[i].name, database[i].surname, database[i].IndexNr, database[i].avg);

        if (ferror(plik))
        {
            printf("\nBlad przy zapisywaniu pliku :C\n");
        }
    }

    fclose(plik);
}