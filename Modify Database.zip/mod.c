#include "load_and_save.h"
#include "mod.h"

void ModifyData(struct Student* database,int databaseSize, int index)
{
    int end = 0,choice;
    do
    {
        
        printf("\nNapisz:\n1 - jesli chcesz edytowac imie\n2 - nazwisko\n3 - numer indeksu\n4 - srednia\n");
        scanf("%d", &choice);

        if (choice == 1)
        {
            ModifyName(database, index);
        }
        else if (choice == 2)
        {
            ModifySurname(database, index);
        }
        else if (choice == 3)
        {
            ModifyIndex(database,databaseSize, index);
        }
        else if (choice == 4)
        {
            ModifyAvg(database, index);
        }

        printf("\nWpisz 1, jesli chcesz edytowac kolejne dane tego studenta: ");
        scanf("%d", &end);

    } while (end == 1);

    return;
}

void NoCommas(char string[])
{
    for (int i = 0; i < strlen(string); i++)
    {
        if (string[i] == ',')
        {
            for (int j = i; j < strlen(string); j++)
            {
                string[j] = string[j + 1];
            }
        }
    }
}

void ModifyName(struct Student* database, int index)
{
    char string[50];
    int confirm;

    printf("\nWpisz nowe imie studenta: ");
    scanf("%s", string);
    NoCommas(string);

    printf("\nNowe imie: %s\nWpisz 1, by potwierdzic: ", string);
    scanf("%d", &confirm);

    if (confirm == 1)
    {
        strcpy(database[index].name, string);
    }
    else
    {
        printf("\nOk, nie to nie :/");
    }

    return;
}

void ModifySurname(struct Student* database, int index)
{
    char string[50];
    int confirm;

    printf("\nWpisz nowe nazwisko studenta: ");
    scanf("%s", string);
    NoCommas(string);

    printf("\nNowe nazwisko: %s\nWpisz 1, by potwierdzic: ", string);
    scanf("%d", &confirm);

    if (confirm == 1)
    {
        strcpy(database[index].surname, string);
    }
    else
    {
        printf("\nOk, nie to nie :/");
    }

    return;
}

void ModifyIndex(struct Student* database,int databaseSize, int index)
{
    int num, confirm;

    printf("\nWpisz nowy indeks studenta (4 cyfry max): ");
    scanf("%d", &num);

    if (num > 9999 || num < 0)
    {
        printf("\nBłąd. Zła liczba >:( ");
        return;
    }

    if(CheckNr(database,databaseSize,num))
    {
        printf("\nNiestety jest juz taki indeks :(");
        return;
    }
    
    printf("\nNowy indeks: %d\nWpisz 1, by potwierdzic: ", num);
    scanf("%d", &confirm);

    if (confirm == 1)
    {
        database[index].IndexNr = num;
    }
    else
    {
        printf("\nOk, nie to nie :/");
    }

    return;
}

void ModifyAvg(struct Student* database, int index)
{
    float num;
    int confirm;

    printf("\nWpisz nowa srednia studenta: ");
    scanf("%f", &num);

    if (num >= 5 || num <= 2)
    {
        printf("\nBlad. Zla liczba >:( ");
        return;
    }

    printf("\nNowa srednia: %f\nWpisz 1, by potwierdzic: ", num);
    scanf("%d", &confirm);

    if (confirm == 1)
    {
        database[index].avg = num;
    }
    else
    {
        printf("\nOk, nie to nie :/");
    }

    return;
}

int CheckNr(struct Student* database,int databaseSize,char answer[])
{
    for (int i = 0; i < databaseSize; i++)
            {
                if (database[i].IndexNr == answer)
                    {
                        return 1;
                    }
            }
    return 0;
}