#ifndef LOAD_AND_SAVE
#define LOAD_AND_SAVE

struct Student
{
    char name[50];
    char surname[50];
    int IndexNr;
    float avg;
};

void LoadDatabase(const char* file_name, struct Student** database, int* databaseSize);
void SaveToFile(const char* file_name, struct Student* database, int databaseSize);

#endif

