#ifndef SEARCH_H
#define SEARCH_H

int SearchByIndex(struct Student* database, int databaseSize);
int SearchBySurname(struct Student* database, int databaseSize);
int CompareStrings(char str1[], char str2[]);

#endif