#ifndef MODIFY_DATA
#define MODIFY_DATA

void NoCommas(char string[]);
void ModifyData(struct Student* database,int databaseSize,int index);
void ModifyName(struct Student* database, int index);
void ModifySurname(struct Student* database, int index);
void ModifyIndex(struct Student* database,int databaseSize, int index);
void ModifyAvg(struct Student* database, int index);
int CheckNr(struct Student* database,int databaseSize,char answer[]);

#endif