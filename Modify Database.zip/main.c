#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "load_and_save.h"
#include "mod.h"
#include "search.h"


int main()
{
    struct Student* database = NULL;
    int databaseSize = 0;
    int choice, index, end;

    LoadDatabase("student_database.csv", &database, &databaseSize);

    do
    {
        printf("\nWybierz:\n1 - jesli chcesz wyszukac po nr. indeksu\n2 - jesli po nazwisku\n");
        scanf("%d", &choice);
        
        if (choice == 1)
        {
            index = SearchByIndex(database, databaseSize);
        }
        else if (choice == 2)
        {
            index = SearchBySurname(database, databaseSize);
        }

        if (index != -1)
        {
            ModifyData(database,databaseSize,index);
        }

        printf("\nJesli chcesz wyszukac kolejnego studenta, napisz 1: ");
        scanf("%d", &end);
        choice = 0;

    } while (end == 1);

    SaveToFile("student_database.csv", database, databaseSize);

    free(database);

    printf("\nZycze milego dnia ;)\n");
    return 0;
}
