#ifndef STUDENT_H
#define STUDENT_H

#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[60];
    char surname[60];
    int id;
    float avg;
    char avgOperator[2]; // Dodajemy pole do przechowywania operatora porównania
} StudentData;

FILE* openFile();
StudentData getData();
void findStudent(StudentData data, FILE *pliczusiunio);
void delStudent();

#endif //STUDENT_H