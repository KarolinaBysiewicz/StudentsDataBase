#include "student.h"

int main() {
    while (1) {
        printf("Wybierz opcje:\n");
        printf("1. Wyszukaj studenta\n");
        printf("2. Usun studenta\n");
        printf("3. Wyjscie\n");

        int choice;
        scanf("%d", &choice);

        switch (choice) {
            case 1: {
                FILE *file = openFile();
                if (file != NULL) {
                    printf("\n");
                    StudentData data = getData();
                    findStudent(data, file);
                    fclose(file);
                }
                break;
            }
            case 2: {
                delStudent();
                break;
            }
            case 3:
                return 0;
            default:
                printf("Nieznana opcja, sprobuj ponownie.\n");
        }
    }
}